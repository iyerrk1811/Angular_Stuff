var stevesApp = {};
stevesApp.person = 'Steve';

stevesApp.logPerson = function(){
    console.log(stevesApp.person);
}