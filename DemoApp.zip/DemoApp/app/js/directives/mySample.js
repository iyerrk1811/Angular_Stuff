'use strict';

eventsApp.directive('mySample', function($compile){
	return {
		//restrict: 'E',
		//using as a class
		restrict: 'C',
		/*link: function(scope, element, attrs, controller) {
			var markup = "<input type='text' ng-model='sampleData'/> {{sampleData}} <br/>";
			angular.element(element).html($compile(markup)(scope));
			}
		*/
		//Now using only the html code without link:
		template: "<input type='text' ng-model='sampleData'/> {{sampleData}} <br/>",
		scope: {
			
		}
		
	};
});

