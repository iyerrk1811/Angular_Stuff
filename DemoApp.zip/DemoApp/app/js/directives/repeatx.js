eventsApp.directive('repeatX', function($compile){
	return {
		//when link is used
		//link: function(scope, element, attributes, controller) {
		compile: function(element, attributes) {
			for (var i = 0; i < Number(attributes.repeatX)-1; i++) {
				//when compile function was used here and link outside
				//element.after($compile(element.clone().attr('repeat-x', 0))(scope));
				element.after(element.clone().attr('repeat-x', 0));
			}
			return function(scope, element, attributes, controller) {
				attributes.$observe('text', function(newValue) {
					if(newValue === 'Hello World'){
						element.css('color', 'red');
					}
				});
			}
		}		
	};
});