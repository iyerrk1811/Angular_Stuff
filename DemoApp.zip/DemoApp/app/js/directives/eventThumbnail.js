'use strict';

eventsApp.directive('eventThumbnail', function(){
	return {
		restrict: 'E',
		replace: true,	//replaces the custom element used by the directive html instead of appending to it
		templateUrl: '/templates/directives/eventThumbnail.html',
		scope: {
			event: "="
		}
	};
});

