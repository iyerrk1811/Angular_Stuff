'use strict';

eventsApp.directive('greeting', function() {
	return {
		restrict: 'E',
		//priority: -1,
		replace: true,	//replaces the custom element used by the directive html instead of appending to 
		transclude: true,
		template: "<div><button class ='btn' ng-click='sayHello()'>Say Hello</button><div ng-transclude></div></div>",
		//controller: 'GreetingController'
		/*used in angular js fundamentals 6.7
		controller: '@',
		name: 'ctrl'
		*/
		controller: function($scope){
			var greetings =	['hello']; 
			$scope.sayHello = function(){
				alert(greetings.join());
			}
			this.addGreeting = function(greeting){
				greetings.push(greeting);
			}
		}
	};
})
.directive('finnish', function(){
	return {
		restrict: 'A',
		//priority: -1,
		require: '^greeting',
		
		//terminal: true,
		link: function(scope, element, attrs, controller){
			controller.addGreeting('hei');
		}
	}
})
.directive('hindi', function(){
	return {
		restrict: 'A',
		//priority: -2,
		require: '^greeting',
		
		link: function(scope, element, attrs, controller){
			controller.addGreeting('नमस्ते');
		}
	}
});
/*used in angular js fundamentals 6.7
eventsApp.controller('GreetingController',
	function($scope){
		$scope.sayHello = function(){
			alert('Hello');
		}
	});
*/