'use strict';

eventsApp.directive('my-sample', function($compile){
	return {
		link: function(scope, element, sttrs, controller) {
			var markup = "<input type='text' ng-model='sampleData' />{{sampleData}}<br/>"
			angular.element(element).html($compile(markup)(scope));	
		}
	};
});